Downloaded data lands here when you run `python run_pipeline.py`. It is not committed to GitHub.
